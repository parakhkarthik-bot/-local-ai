# Local Assistant

A browser-only chat app. A worker runs quantized Transformers.js models on your device. There is no inference API, account, or application backend.

## Project structure

- `index.html` — full UI, CSS, history, Markdown renderer, calculator, and model worker source.
- `sw.js` — service worker for offline reloads and runtime assets. Browsers require this to be a separate same-origin script.
- `.nojekyll` — serve the source unchanged on GitHub Pages.
- `README.md` — deployment and operating notes.

## Deploy on GitHub Pages

1. Extract the archive and commit the files themselves at the root of a GitHub repository, including `.nojekyll`.
2. In repository Settings → Pages, choose **Deploy from a branch**, select `main` and `/(root)`, then save. Open the published HTTPS address shown in Pages. No build step or browser-side installation is required.
3. Leave the app open until Qwen is ready. Generate one response on the intended backend, then disconnect and reload to verify offline operation on your device. Repeat online for each model/backend you intend to use offline. Prefer a current Chromium-based browser; Auto uses WebGPU when available and retries model initialization with single-threaded WASM if necessary. If generation fails after a successful GPU load, select WASM manually.

## Downloads vs. local inference

The default first launch fetches pinned Transformers.js runtime files from jsDelivr and a pinned model snapshot from Hugging Face. No chat content is sent to either service. A fresh browser cannot both automatically download weights and avoid all external servers unless the assets have already been supplied locally. After provisioning, shell/runtime assets use service-worker caches, models use the Transformers.js browser cache, and chat history uses localStorage. Cache eviction, private browsing, storage quotas, and switching the site origin can invalidate offline availability. Saving a model is not the same as saving it on all devices. Request persistent storage via Options if supported.

### No external requests on first launch: provision the assets yourself

The ZIP contains source, not model weights. On a machine with the assets already available, use the optional `?local=1` mode and serve the directory on localhost (for example, `python -m http.server 8000` if Python is already installed, then open `http://localhost:8000/?local=1`). This is a local static file server, not an inference backend. Place the pinned Transformers.js 3.8.1 browser build and accompanying runtime files (including the ONNX WASM/glue files from its dist directory) under `vendor/`, preserving filenames. Place each selected model snapshot under `models/<repo-owner>/<repo-name>/`, preserving its repository paths (tokenizers, configs, chat template if supplied, `onnx/model_q4.onnx`, and any external tensor files). Model IDs and commit hashes are in `index.html`. Local mode disables the remote model resolver and redirects runtime asset resolution to `vendor/`. For an air-gapped workflow keep the device disconnected and verify that a chat works. `file://` is not a supported deployment target.

## Usage and performance

- Qwen 2.5 0.5B is the default. Llama 3.2 1B, Gemma 3 1B, Phi 3 Mini and TinyLlama are selectable. Model licenses differ; review the repository licenses before redistributing weights.
- Generating uses one worker/model at a time, 4-bit weights, greedy decoding, a 2,048-token input budget and a capped output budget. The oldest turns are dropped from model context as needed; they remain in history. A quick stop may unload the model if a backend does not yield promptly.
- The readout shows generation speed after the first token, observed model-file bytes when available, and a coarse browser-reported device RAM class where supported. Model-file bytes are **not** RAM/VRAM usage; there is no portable browser measurement of live model RAM or VRAM.
- `/calc` handles arithmetic locally without a model: decimals, parentheses, unary signs, `+ - * / %`. It uses JavaScript floating-point arithmetic. Summarization, translation, reasoning and coding use the model; review outputs carefully. Small models do not match hosted frontier systems. Low-memory phones may fail to load even a small model.

## Security and privacy

- The app does not render raw HTML from chat output, load model-suggested image URLs, execute generated code, or use `eval` for arithmetic. Markdown support is intentionally limited to headings, emphasis, lists, inline code, and fenced code with simple syntax colors.
- Chats are stored unencrypted in this browser profile. Other scripts on the same origin may access them. Prefer a dedicated origin; GitHub Pages project sites under one account may share an origin. Clearing site data deletes conversations and caches. Deleting a conversation does not remove model files.
- A hosted operator or compromised dependency could change the app. Review the source and provision reviewed runtime files locally for sensitive use. No background sync or telemetry is implemented.
