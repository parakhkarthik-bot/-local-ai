const scope=new URL(self.registration.scope), name=`local-assistant-shell-v1:${scope.pathname}`;
self.addEventListener('install',e=>e.waitUntil((async()=>{const c=await caches.open(name);await c.add(new URL('index.html',scope));await self.skipWaiting()})()));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const u=new URL(e.request.url), entry=new URL('index.html',scope);
  const shell=u.origin===scope.origin&&(u.pathname===scope.pathname||u.pathname===entry.pathname);
  const runtime=u.origin==='https://cdn.jsdelivr.net'&&/^\/npm\/(?:@huggingface\/transformers@3\.8\.1|onnxruntime-web@[^/]+)\//.test(u.pathname);
  const vendor=u.origin===scope.origin&&u.pathname.startsWith(new URL('vendor/',scope).pathname);
  if(!shell&&!runtime&&!vendor)return;
  e.respondWith((async()=>{const c=await caches.open(name);if(shell){try{const r=await fetch(e.request);if(r.ok){try{await c.put(entry,r.clone())}catch{}}return r}catch{return await c.match(entry)||Response.error()}}const hit=await c.match(e.request);if(hit)return hit;const r=await fetch(e.request);if(r.ok||r.type==='opaque'){try{await c.put(e.request,r.clone())}catch{}}return r})());
});
